/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DI;

/**
 *
 * @author Tharindu
 */
public class Resturent {
    TeaMaker t;

    public void setT(TeaMaker t) {
        this.t = t;
    }
    String welcomenote;

    public void setWelcomenote(String welcomenote) {
        this.welcomenote = welcomenote;
    }
// public Resturent(TeaMaker tm){
//     this.t=tm;
// } 
 public void hotproducts(){
     t.preparetea();
 }
 public void Welcome(){
     System.out.println(welcomenote);
 }
 
 public void init(){
 }
 public void destroy(){
 }
}
